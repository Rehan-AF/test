const AccordionData = [
  {
    title: "Why Slothz?",
    discp:
      "Cute, soft and slow VERY slow, sloths are very cool animals but sadly they are endangered by humans, from illegal trade to deforestation, and we want to raise awareness on them.",
  },
  {
    title: "What is Minting Process",
    discp:
      "Tokens will be minted through a blind and random mint using our in-house script (open source and proof of hashes). No FOMO ramp & flat pricing. Minters can get up to 20 at a time.",
  },
  {
    title: "Tell us more about the SLOTHz !",
    discp:
      "Every Sloth is randomly generated with a different amount of traits specifically designed to look as good as possible with well designed accessories and meeting high standards of quality and randomness.",
  },
  {
    title: "Why Slothz?",
    discp:
      "Cute, soft and slow VERY slow, sloths are very cool animals but sadly they are endangered by humans, from illegal trade to deforestation, and we want to raise awareness on them.",
  },
  {
    title: "What is Minting Process",
    discp:
      "Tokens will be minted through a blind and random mint using our in-house script (open source and proof of hashes). No FOMO ramp & flat pricing. Minters can get up to 20 at a time.",
  },
  {
    title: "Tell us more about the SLOTHz !",
    discp:
      "Every Sloth is randomly generated with a different amount of traits specifically designed to look as good as possible with well designed accessories and meeting high standards of quality and randomness.",
  },
  {
    title: "Why Slothz?",
    discp:
      "Cute, soft and slow VERY slow, sloths are very cool animals but sadly they are endangered by humans, from illegal trade to deforestation, and we want to raise awareness on them.",
  },
  {
    title: "What is Minting Process",
    discp:
      "Tokens will be minted through a blind and random mint using our in-house script (open source and proof of hashes). No FOMO ramp & flat pricing. Minters can get up to 20 at a time.",
  },
  {
    title: "Tell us more about the SLOTHz !",
    discp:
      "Every Sloth is randomly generated with a different amount of traits specifically designed to look as good as possible with well designed accessories and meeting high standards of quality and randomness.",
  },
];
export default AccordionData;
